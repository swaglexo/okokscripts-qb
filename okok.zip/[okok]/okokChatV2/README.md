Hi, thank you for buying okokChat! :)

If you need help contact me on discord: okok#3488
Discord server: https://discord.gg/okok

1. Download the latest 'chat' resource: https://github.com/citizenfx/cfx-server-data/tree/master/resources/%5Bgameplay%5D/chat.

2. Make sure to start 'chat' before 'okokChatV2' and to start 'okokChatV2' after 'qb-core'.

3. Configure the 'config.lua' file to your liking.

Converted script from ESX to QBCore by RafaEl.Zgz (https://www.rab-devs.com) - Also has some improvements