Config = {}

Config.Key = 38 -- [E] Key to open the interaction, check here the keys ID: https://docs.fivem.net/docs/game-references/controls/#controls

Config.AutoCamPosition = true -- If true it'll set the camera position automatically

Config.AutoCamRotation = true -- If true it'll set the camera rotation automatically

Config.HideMinimap = true -- If true it'll hide the minimap when interacting with an NPC

Config.UseOkokTextUI = true -- If true it'll use okokTextUI 

Config.CameraAnimationTime = 1000 -- Camera animation time: 1000 = 1 second

Config.TalkToNPC = {
	
	{
		npc = 'a_m_m_prolhost_01', 										-- Website too see peds name: https://wiki.rage.mp/index.php?title=Peds
		header = 'Employee of the', 								-- Text over the name
		name = 'City', 										-- Text under the header
		uiText = "City Employee",							-- Name shown on the notification when near the NPC
		dialog = 'Hey, how can I help you?',						-- Text showm on the message bubble 
		coordinates = vector3(395.41, 0.97, 90.94), 				-- coordinates of NPC
		heading = 160.0,											-- Heading of NPC (needs decimals, 0.0 for example)
		camOffset = vector3(0.0, 0.0, 0.0), 						-- Camera position relative to NPC 	| (only works if Config.AutoCamPosition = false)
		camRotation = vector3(0.0, 0.0, 0.0),						-- Camera rotation 					| (only works if Config.AutoCamRotation = false)
		interactionRange = 2.5, 									-- From how far the player can interact with the NPC
		options = {													-- Options shown when interacting (Maximum 6 options per NPC)
			{'Where i can get the driver license?', 'okokTalk:license', 'c'},		-- 'c' for client
			{'When I can start the builder job?', 'okokTalk:builder', 'c'},		-- 's' for server (if you write something else it'll be server by default)
			{"Where i can start the farmer job?", 'okokTalk:farmer', 'c'}, 
			{"Where i can start the fisher job?", 'okokTalk:fisher', 'c'}, 
			{"Where i can start the miner job?", 'okokTalk:miner', 'c'}, 
			{"Where i can Apply for A job?", 'okokTalk:apply', 'c'}, 
		},
		jobs = {													-- Jobs that can interact with the NPC
			
		},
	},
	
	--[[
	-- This is the template to create new NPCs
	{
		npc = "",
		header = "",
		name = "",
		uiText = "",
		dialog = "",
		coordinates = vector3(0.0, 0.0, 0.0),
		heading = 0.0,
		camOffset = vector3(0.0, 0.0, 0.0),
		camRotation = vector3(0.0, 0.0, 0.0),
		interactionRange = 0,
		options = {
			{"", 'client:event', 'c'},
			{"", 'client:event', 'c'},
			{"", 'client:event', 'c'}, 
			{"", 'server:event', 's'}, 
			{"", 'server:event', 's'}, 
			{"", 'server:event', 's'}, 
		},
		jobs = {	-- Example jobs
			'police',
			'ambulance',
		},
	},
	]]--
}