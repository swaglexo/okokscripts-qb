
add this to your qbcore/shered/items


			['contract'] = {['name'] = 'contract', ['label'] = 'Contract', ['weight'] = 1, ['type'] = 'item', ['image'] = 'contract.png', ['unique'] = true, ['useable'] = true, ['shouldClose'] = true, ['combinable'] = nil, ['description'] = 'A contract'},
